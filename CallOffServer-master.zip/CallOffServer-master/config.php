<?php 
	$musql_host_name = "localhost";
	$mysql_user_name = "root";
	$mysql_password = "";
	$dbname="calloff";



?>